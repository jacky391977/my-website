import { EssentialOil, ScentKeywords, BlendingResult, FragranceProfile, BlendAnalysis, ApplicationSuggestion, EnhancedBlendingResult, OilCharacteristics, BlendingRecipe } from '../types/EssentialOil';

export class FragranceEngine {
  private oils: EssentialOil[] = [];
  private keywords: ScentKeywords = {};
  private purchaseLinks: Record<string, string> = {};
  private oilCharacteristics: Record<string, OilCharacteristics> = {};

  async initialize() {
    try {
      const [oilsResponse, keywordsResponse, purchaseLinksResponse, characteristicsResponse] = await Promise.all([
        fetch('/data/essential_oils_list.json'),
        fetch('/data/scent_keywords.json'),
        fetch('/data/purchase_links.json'),
        fetch('/data/oil_characteristics.json')
      ]);
      
      const oilsData = await oilsResponse.json();
      const keywordsData = await keywordsResponse.json();
      const purchaseLinksData = await purchaseLinksResponse.json();
      const characteristicsData = await characteristicsResponse.json();
      
      this.oils = oilsData.essential_oils;
      this.keywords = keywordsData.scent_keywords;
      this.purchaseLinks = purchaseLinksData.purchase_links;
      this.oilCharacteristics = characteristicsData.oil_characteristics;
    } catch (error) {
      console.error('Failed to initialize fragrance engine:', error);
    }
  }

  analyzeFragranceRequest(input: string): BlendingResult {
    const normalizedInput = input.toLowerCase();
    const matches: { oil: EssentialOil; score: number; reasons: string[] }[] = [];

    // 分析輸入文本中的關鍵詞
    for (const [keyword, oilNames] of Object.entries(this.keywords)) {
      if (normalizedInput.includes(keyword)) {
        // 為每個匹配的關鍵詞找到對應的精油
        for (const oilName of oilNames) {
          const oil = this.findOilByEnglishName(oilName);
          if (oil) {
            const existingMatch = matches.find(m => m.oil.id === oil.id);
            if (existingMatch) {
              existingMatch.score += 1;
              existingMatch.reasons.push(keyword);
            } else {
              matches.push({
                oil,
                score: 1,
                reasons: [keyword]
              });
            }
          }
        }
      }
    }

    // 分析精油屬性匹配
    for (const oil of this.oils) {
      for (const property of oil.properties) {
        if (normalizedInput.includes(property)) {
          const existingMatch = matches.find(m => m.oil.id === oil.id);
          if (existingMatch) {
            existingMatch.score += 2; // 屬性匹配權重更高
            existingMatch.reasons.push(`屬性:${property}`);
          } else {
            matches.push({
              oil,
              score: 2,
              reasons: [`屬性:${property}`]
            });
          }
        }
      }
    }

    // 分析香氣描述匹配
    for (const oil of this.oils) {
      if (normalizedInput.includes(oil.scent_profile.replace(/香$/, '')) || 
          normalizedInput.includes(oil.chinese_name.replace(/精油$/, ''))) {
        const existingMatch = matches.find(m => m.oil.id === oil.id);
        if (existingMatch) {
          existingMatch.score += 3; // 直接匹配權重最高
          existingMatch.reasons.push('直接匹配');
        } else {
          matches.push({
            oil,
            score: 3,
            reasons: ['直接匹配']
          });
        }
      }
    }

    // 排序並選擇最佳匹配
    matches.sort((a, b) => b.score - a.score);

    if (matches.length === 0) {
      // 沒有匹配，返回熱門推薦
      const popularOils = this.oils.filter(oil => 
        ['真正薰衣草精油', '檸檬精油', '甜橙精油'].includes(oil.chinese_name)
      );
      return {
        type: 'blend',
        oils: popularOils,
        reason: '基於您的描述，我們推薦這些經典的精油組合',
        confidence: 0.3
      };
    }

    const topMatches = matches.slice(0, 3);
    const bestMatch = topMatches[0];

    // 決定推薦單方還是複方
    if (bestMatch.score >= 3 && topMatches.length === 1) {
      return {
        type: 'single',
        oils: [bestMatch.oil],
        reason: `根據您的描述「${bestMatch.reasons.join('、')}」，我們推薦這款精油`,
        confidence: Math.min(bestMatch.score / 3, 1)
      };
    } else {
      const blendOils = topMatches.map(m => m.oil);
      const allReasons = [...new Set(topMatches.flatMap(m => m.reasons))];
      return {
        type: 'blend',
        oils: blendOils,
        reason: `基於您提到的「${allReasons.join('、')}」特徵，建議調配這些精油`,
        confidence: Math.min(topMatches.reduce((sum, m) => sum + m.score, 0) / (topMatches.length * 3), 1)
      };
    }
  }

  analyzeBlendProfile(profile: FragranceProfile): BlendAnalysis {
    const recommendedOils: EssentialOil[] = [];
    const applications: ApplicationSuggestion[] = [];

    // 根據前中後調選擇精油
    if (profile.top) {
      const topOils = this.findOilsByDescription(profile.top, 'top');
      recommendedOils.push(...topOils.slice(0, 2));
    }
    if (profile.middle) {
      const middleOils = this.findOilsByDescription(profile.middle, 'middle');
      recommendedOils.push(...middleOils.slice(0, 2));
    }
    if (profile.base) {
      const baseOils = this.findOilsByDescription(profile.base, 'base');
      recommendedOils.push(...baseOils.slice(0, 2));
    }

    // 生成應用場合建議
    const characteristics = [profile.top, profile.middle, profile.base].filter(Boolean);
    applications.push(...this.generateApplicationSuggestions(characteristics));

    // 生成香調演變描述
    const evolution = this.generateEvolutionDescription(profile);

    return {
      profile,
      evolution,
      applications,
      recommendedOils: this.removeDuplicateOils(recommendedOils)
    };
  }

  private findOilByEnglishName(englishName: string): EssentialOil | undefined {
    const normalizedName = englishName.toLowerCase().replace(/_/g, ' ');
    return this.oils.find(oil => 
      oil.name.toLowerCase().includes(normalizedName) ||
      normalizedName.includes(oil.name.toLowerCase())
    );
  }

  private findOilsByDescription(description: string, noteType?: 'top' | 'middle' | 'base'): EssentialOil[] {
    const normalizedDesc = description.toLowerCase();
    const matches: { oil: EssentialOil; score: number }[] = [];

    for (const oil of this.oils) {
      if (noteType && oil.notes !== noteType) continue;
      
      let score = 0;
      
      // 檢查關鍵詞匹配
      for (const [keyword, oilNames] of Object.entries(this.keywords)) {
        if (normalizedDesc.includes(keyword)) {
          const oilNameMatch = oilNames.some(name => 
            oil.name.toLowerCase().includes(name.replace(/_/g, ' '))
          );
          if (oilNameMatch) score += 2;
        }
      }
      
      // 檢查屬性匹配
      for (const property of oil.properties) {
        if (normalizedDesc.includes(property)) {
          score += 3;
        }
      }
      
      // 檢查香氣描述匹配
      if (normalizedDesc.includes(oil.scent_profile.replace(/香$/, ''))) {
        score += 3;
      }
      
      if (score > 0) {
        matches.push({ oil, score });
      }
    }
    
    return matches
      .sort((a, b) => b.score - a.score)
      .map(m => m.oil);
  }

  private generateApplicationSuggestions(characteristics: string[]): ApplicationSuggestion[] {
    const suggestions: ApplicationSuggestion[] = [];
    const charText = characteristics.join(' ').toLowerCase();

    if (charText.includes('清新') || charText.includes('提神')) {
      suggestions.push({
        occasion: '辦公室',
        description: '提升專注力，保持清醒狀態',
        icon: '💼'
      });
    }

    if (charText.includes('放鬆') || charText.includes('舒緩')) {
      suggestions.push({
        occasion: '睡前',
        description: '幫助放鬆身心，促進睡眠品質',
        icon: '🌙'
      });
    }

    if (charText.includes('花香') || charText.includes('浪漫')) {
      suggestions.push({
        occasion: '約會',
        description: '營造浪漫氛圍，增添個人魅力',
        icon: '💕'
      });
    }

    if (charText.includes('提神') || charText.includes('活力')) {
      suggestions.push({
        occasion: '運動後',
        description: '恢復活力，舒緩疲勞感',
        icon: '🏃'
      });
    }

    if (suggestions.length === 0) {
      suggestions.push({
        occasion: '日常使用',
        description: '適合日常薰香，改善生活品質',
        icon: '🏠'
      });
    }

    return suggestions;
  }

  private generateEvolutionDescription(profile: FragranceProfile): string {
    const parts: string[] = [];
    
    if (profile.top) {
      parts.push(`初聞時展現${profile.top}的特質`);
    }
    if (profile.middle) {
      parts.push(`隨後轉為${profile.middle}的中調`);
    }
    if (profile.base) {
      parts.push(`最終沈澱為${profile.base}的基調`);
    }
    
    return parts.join('，') + '，形成層次豐富的香氣體驗。';
  }

  private removeDuplicateOils(oils: EssentialOil[]): EssentialOil[] {
    const seen = new Set<number>();
    return oils.filter(oil => {
      if (seen.has(oil.id)) {
        return false;
      }
      seen.add(oil.id);
      return true;
    });
  }

  getOilsByNoteType(noteType: 'top' | 'middle' | 'base'): EssentialOil[] {
    return this.oils.filter(oil => oil.notes === noteType);
  }

  getAllOils(): EssentialOil[] {
    return this.oils;
  }

  analyzeFragranceRequestEnhanced(input: string): EnhancedBlendingResult {
    const normalizedInput = input.toLowerCase();
    const matches: { oil: EssentialOil; score: number; reasons: string[] }[] = [];

    // 分析輸入文本中的關鍵詞
    for (const [keyword, oilNames] of Object.entries(this.keywords)) {
      if (normalizedInput.includes(keyword)) {
        for (const oilName of oilNames) {
          const oil = this.findOilByEnglishName(oilName);
          if (oil) {
            const existingMatch = matches.find(m => m.oil.id === oil.id);
            if (existingMatch) {
              existingMatch.score += 1;
              existingMatch.reasons.push(keyword);
            } else {
              matches.push({
                oil,
                score: 1,
                reasons: [keyword]
              });
            }
          }
        }
      }
    }

    // 分析精油屬性匹配
    for (const oil of this.oils) {
      for (const property of oil.properties) {
        if (normalizedInput.includes(property)) {
          const existingMatch = matches.find(m => m.oil.id === oil.id);
          if (existingMatch) {
            existingMatch.score += 2;
            existingMatch.reasons.push(`屬性:${property}`);
          } else {
            matches.push({
              oil,
              score: 2,
              reasons: [`屬性:${property}`]
            });
          }
        }
      }
    }

    // 分析香氣描述匹配
    for (const oil of this.oils) {
      if (normalizedInput.includes(oil.scent_profile.replace(/香$/, '')) || 
          normalizedInput.includes(oil.chinese_name.replace(/精油$/, ''))) {
        const existingMatch = matches.find(m => m.oil.id === oil.id);
        if (existingMatch) {
          existingMatch.score += 3;
          existingMatch.reasons.push('直接匹配');
        } else {
          matches.push({
            oil,
            score: 3,
            reasons: ['直接匹配']
          });
        }
      }
    }

    // 排序並選擇最佳匹配
    matches.sort((a, b) => b.score - a.score);

    const result: EnhancedBlendingResult = {};

    if (matches.length === 0) {
      // 沒有匹配，返回熱門推薦
      const popularOils = this.oils.filter(oil => 
        ['真正薰衣草精油', '檸檬精油', '甜橙精油'].includes(oil.chinese_name)
      );
      result.blendRecommendation = {
        oils: popularOils,
        reason: '基於您的描述，我們推薦這些經典的精油組合',
        confidence: 0.3
      };
      return result;
    }

    const bestMatch = matches[0];
    const topMatches = matches.slice(0, 3);

    // 單方推薦條件：最高分數 >= 4 且明顯高於其他
    if (bestMatch.score >= 4 && (matches.length === 1 || bestMatch.score > matches[1].score + 1)) {
      const characteristics = this.oilCharacteristics[bestMatch.oil.name];
      if (characteristics) {
        result.singleRecommendation = {
          oil: bestMatch.oil,
          characteristics,
          reason: `根據您的描述「${bestMatch.reasons.join('、')}」，這款單方精油完美符合您的需求`,
          confidence: Math.min(bestMatch.score / 4, 1)
        };
      }
    }

    // 複方推薦：當有多個中等匹配或單方推薦之外的補充推薦
    if (topMatches.length >= 2) {
      const blendOils = topMatches.map(m => m.oil);
      const allReasons = [...new Set(topMatches.flatMap(m => m.reasons))];
      result.blendRecommendation = {
        oils: blendOils,
        reason: `基於您提到的「${allReasons.join('、')}」特徵，建議調配這些精油`,
        confidence: Math.min(topMatches.reduce((sum, m) => sum + m.score, 0) / (topMatches.length * 3), 1)
      };
    }

    return result;
  }

  generateBlendingRecipe(oils: EssentialOil[]): BlendingRecipe {
    // 按香調分類
    const topNotes = oils.filter(oil => oil.notes === 'top');
    const middleNotes = oils.filter(oil => oil.notes === 'middle');
    const baseNotes = oils.filter(oil => oil.notes === 'base');

    const ingredients = [];
    let order = 1;

    // 後調先加（20-30%）
    if (baseNotes.length > 0) {
      for (const oil of baseNotes.slice(0, 2)) {
        ingredients.push({
          oil,
          drops: baseNotes.length === 1 ? 2 : 1,
          percentage: baseNotes.length === 1 ? '30%' : '20%',
          order: order++
        });
      }
    }

    // 中調（30-50%）
    if (middleNotes.length > 0) {
      for (const oil of middleNotes.slice(0, 2)) {
        ingredients.push({
          oil,
          drops: middleNotes.length === 1 ? 3 : 2,
          percentage: middleNotes.length === 1 ? '50%' : '30%',
          order: order++
        });
      }
    }

    // 前調最後加（20-30%）
    if (topNotes.length > 0) {
      for (const oil of topNotes.slice(0, 2)) {
        ingredients.push({
          oil,
          drops: topNotes.length === 1 ? 2 : 1,
          percentage: topNotes.length === 1 ? '30%' : '20%',
          order: order++
        });
      }
    }

    // 如果所有精油都是同一種香調，均勻分配
    if (ingredients.length === 0) {
      for (let i = 0; i < Math.min(oils.length, 3); i++) {
        ingredients.push({
          oil: oils[i],
          drops: Math.ceil(6 / Math.min(oils.length, 3)),
          percentage: `${Math.round(100 / Math.min(oils.length, 3))}%`,
          order: i + 1
        });
      }
    }

    const steps = [
      '準備 10ml 基底油（推薦甜杏仁油或荷荷巴油）倒入調香瓶中',
      '按順序加入精油，每加入一種都要輕柔攪拌',
      '完成後蓋上瓶蓋，輕搖混合',
      '標記日期和配方，靜置 24 小時讓香氣充分融合',
      '使用前可先滴 1-2 滴在手腕測試香氣'
    ];

    const tips = [
      '建議初次調配時先減半用量，測試滿意後再調製正常分量',
      '每次加精油前記錄滴數，方便下次重現喜愛的配方',
      '基底油可選擇無味或淡香型，避免影響精油香氣',
      '調配完成的精油 blend 建議在 6 個月內使用完畢',
      '存放在陰涼乾燥處，避免陽光直射'
    ];

    return {
      baseOil: '甜杏仁油或荷荷巴油',
      totalVolume: '10ml',
      ingredients,
      steps,
      tips
    };
  }

  getOilCharacteristics(oilName: string): OilCharacteristics | undefined {
    return this.oilCharacteristics[oilName];
  }

  getPurchaseLink(oilName: string): string {
    const link = this.purchaseLinks[oilName];
    return link || 'https://www.stardi.com.tw/collections/single-essential-oil';
  }
}