export interface EssentialOil {
  id: number;
  name: string;
  chinese_name: string;
  scent_profile: string;
  notes: 'top' | 'middle' | 'base';
  properties: string[];
}

export interface OilCharacteristics {
  description: string;
  applications: string[];
}

export interface ScentKeywords {
  [key: string]: string[];
}

export interface BlendingResult {
  type: 'single' | 'blend';
  oils: EssentialOil[];
  reason: string;
  confidence: number;
}

export interface EnhancedBlendingResult {
  singleRecommendation?: {
    oil: EssentialOil;
    characteristics: OilCharacteristics;
    reason: string;
    confidence: number;
  };
  blendRecommendation?: {
    oils: EssentialOil[];
    reason: string;
    confidence: number;
  };
}

export interface FragranceProfile {
  top?: string;
  middle?: string;
  base?: string;
}

export interface ApplicationSuggestion {
  occasion: string;
  description: string;
  icon: string;
}

export interface BlendAnalysis {
  profile: FragranceProfile;
  evolution: string;
  applications: ApplicationSuggestion[];
  recommendedOils: EssentialOil[];
}

export interface BlendingRecipe {
  baseOil: string;
  totalVolume: string;
  ingredients: {
    oil: EssentialOil;
    drops: number;
    percentage: string;
    order: number;
  }[];
  steps: string[];
  tips: string[];
}