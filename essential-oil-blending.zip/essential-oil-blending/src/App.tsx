import { useState, useEffect } from 'react';
import { FragranceEngine } from './services/FragranceEngine';
import FragranceSimulator from './components/FragranceSimulator';
import NotesDesigner from './components/NotesDesigner';
import { Sparkles, Layers, ExternalLink, X } from 'lucide-react';

function App() {
  const [fragranceEngine] = useState(() => new FragranceEngine());
  const [isInitialized, setIsInitialized] = useState(false);
  const [activeTab, setActiveTab] = useState<'simulator' | 'designer'>('simulator');
  const [showDisclaimer, setShowDisclaimer] = useState(false);

  useEffect(() => {
    const initializeEngine = async () => {
      await fragranceEngine.initialize();
      setIsInitialized(true);
    };
    initializeEngine();
  }, [fragranceEngine]);

  if (!isInitialized) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-amber-50 to-rose-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mb-4"></div>
          <p className="text-gray-600 text-lg">正在初始化精油資料庫...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-amber-50 to-rose-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-12 bg-transparent rounded-xl flex items-center justify-center overflow-hidden">
                <img 
                  src="/stardi-logo.png" 
                  alt="Stardi Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-1">
                  <span className="text-pink-500">毛毛老師</span>
                  <span className="text-lg text-pink-400 font-light">の</span>
                </h1>
                <p className="text-gray-600 text-sm font-medium tracking-wide">
                  <span className="inline-block">智能</span>
                  <span className="inline-block text-pink-400 mx-1">❤️</span>
                  <span className="inline-block">香氣配方與設計系統</span>
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <a
                href="https://www.stardi.com.tw/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors duration-200"
              >
                <ExternalLink size={16} />
                Stardi 官網
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center gap-2 px-4 py-4 border-b-2 font-medium transition-colors duration-200 ${
                activeTab === 'simulator'
                  ? 'border-green-500 text-green-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Sparkles size={20} />
              香氣模擬器
            </button>
            <button
              onClick={() => setActiveTab('designer')}
              className={`flex items-center gap-2 px-4 py-4 border-b-2 font-medium transition-colors duration-200 ${
                activeTab === 'designer'
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Layers size={20} />
              前中後調設計
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'simulator' && (
          <FragranceSimulator fragranceEngine={fragranceEngine} />
        )}
        {activeTab === 'designer' && (
          <NotesDesigner fragranceEngine={fragranceEngine} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-4">
              <h3 className="font-semibold text-gray-800 mb-3">關於我</h3>
              <div className="text-gray-600 text-sm leading-relaxed space-y-3">
                <p>毛毛老師是香氛品牌創業顧問，也是少數同時擁有產業實戰與教學系統的香氣設計導師。</p>
                <p>致力推廣天然香芬、心靈調香與個人 IP 香氣，整合教育、研發、生產、市場行銷資源，打造一站式香氛品牌創業生態圈。</p>
                <p>協助許多香氛品牌創業者建立個人品牌調香系統，實現香氣創業夢想。</p>
              </div>
            </div>
            <div className="md:col-span-2 md:pl-6">
              <h3 className="font-semibold text-gray-800 mb-3">功能特色</h3>
              <ul className="text-gray-600 text-sm space-y-2">
                <li>• 智能香氣匹配算法</li>
                <li>• 前中後調設計工具</li>
                <li>• 個人化應用建議</li>
                <li>• 專業精油資料庫</li>
              </ul>
            </div>
            <div className="md:col-span-3">
              <h3 className="font-semibold text-gray-800 mb-3">精油購買</h3>
              <p className="text-gray-600 text-sm mb-3">
                所有推薦的精油均可在 Stardi 官方網站購買。
              </p>
              <a
                href="https://www.stardi.com.tw/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 text-sm font-medium"
              >
                <ExternalLink size={16} />
                前往 Stardi 官網
              </a>
            </div>
            <div className="md:col-span-3">
              <h3 className="font-semibold text-gray-800 mb-3">聯絡我們</h3>
              <div className="text-gray-600 text-sm space-y-1">
                <p className="font-medium">星締創研國際有限公司</p>
                <p>統一編號：82850346</p>
                <p>客服專線：(02)8751-5503#10</p>
                <p>信箱：ippa.mao@gmail.com</p>
                <p>地址：台北市內湖區洲子街12號2樓</p>
              </div>
              <div className="mt-4">
                <div className="mb-4">
                  <span className="inline-block bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg transform hover:scale-105 transition-all duration-200">
                    ✨ 追蹤我們 ✨
                  </span>
                </div>
                <div className="flex gap-3">
                  <a 
                    href="https://www.facebook.com/juliamusearoma" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-110"
                    title="Facebook"
                  >
                    <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                  </a>
                  <a 
                    href="https://www.instagram.com/ippa_mao/?fbclid=IwAR1obwBhNPRUOjPyxd5SGxKNvApvARk2Tb_t18TL98ZUe6CpdL4wupA4qQo" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-110"
                    title="Instagram"
                  >
                    <svg className="w-5 h-5 text-pink-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                    </svg>
                  </a>
                  <a 
                    href="https://line.me/R/ti/p/@164duttg?from=page&searchId=164duttg" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-110"
                    title="LINE"
                  >
                    <svg className="w-5 h-5 text-green-500" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/>
                    </svg>
                  </a>
                  <a 
                    href="https://www.youtube.com/@maomao_aroma" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-110"
                    title="YouTube"
                  >
                    <svg className="w-5 h-5 text-red-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-8 pt-8 text-center">
            <p className="text-gray-500 text-sm mb-2">
              © 2025 毛毛老師 - 學員 / 客戶專屬智能調香系統
            </p>
            <button
              onClick={() => setShowDisclaimer(true)}
              className="text-gray-400 hover:text-gray-600 text-xs underline transition-colors duration-200"
            >
              免責聲明
            </button>
          </div>
        </div>
      </footer>

      {/* 免責聲明模態框 */}
      {showDisclaimer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-800">免責聲明</h2>
                <button
                  onClick={() => setShowDisclaimer(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  <X size={24} />
                </button>
              </div>
              <div className="text-gray-600 space-y-4 text-sm leading-relaxed">
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                  <p className="font-semibold text-yellow-800 mb-2">重要提醒</p>
                  <p className="text-yellow-700">
                    本系統僅提供參考使用，所有調香建議與精油配方均以毛毛老師的教學內容為主。
                  </p>
                </div>
                
                <h3 className="font-semibold text-gray-800">使用條件與限制</h3>
                <ul className="list-disc list-inside space-y-2 text-gray-600">
                  <li>本智能調香系統為輔助性工具，不可取代專業調香師的指導</li>
                  <li>系統推薦的配方僅供參考，實際使用前請諮詢專業老師</li>
                  <li>使用者應具備基本精油知識與安全使用概念</li>
                  <li>建議參加毛毛老師的正式課程以獲得完整訓練</li>
                </ul>

                <h3 className="font-semibold text-gray-800">安全聲明</h3>
                <ul className="list-disc list-inside space-y-2 text-gray-600">
                  <li>使用精油前請阅讀產品說明與安全指引</li>
                  <li>孕婦、哺乳婦女、兒童與患有特定疾病者請謹慎使用</li>
                  <li>初次使用前請進行皮膚測試，确認無過敏反應</li>
                  <li>精油應稀釋後使用，不建議直接接觸皮膚</li>
                  <li>若出現不適症狀，請立即停止使用並諮詢醫師</li>
                </ul>

                <h3 className="font-semibold text-gray-800">法律責任</h3>
                <p className="text-gray-600">
                  星締創研國際有限公司及毛毛老師不對使用者使用本系統所產生的任何直接或間接損失承擔責任。使用者應自行承擔使用本系統的風險與責任。
                </p>

                <h3 className="font-semibold text-gray-800">教育目的</h3>
                <p className="text-gray-600">
                  本系統旨在提供學習與探索的平台，幫助使用者更好地理解精油與香氣的組合。我們鼓勵所有使用者繼續深入學習，參加正式的香氣設計課程。
                </p>

                <div className="bg-green-50 border-l-4 border-green-400 p-4 mt-6">
                  <p className="font-semibold text-green-800 mb-2">聯絡方式</p>
                  <p className="text-green-700">
                    若有任何疑問或需要專業指導，歡迎聯絡毛毛老師：<br/>
                    電話：(02)8751-5503#10<br/>
                    信箱：ippa.mao@gmail.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;