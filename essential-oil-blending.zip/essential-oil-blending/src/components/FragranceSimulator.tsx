import { useState } from 'react';
import { FragranceEngine } from '../services/FragranceEngine';
import { EnhancedBlendingResult } from '../types/EssentialOil';
import { Search, Sparkles, Star, Lightbulb } from 'lucide-react';
import OilCard from './OilCard';
import BlendingGuide from './BlendingGuide';

interface FragranceSimulatorProps {
  fragranceEngine: FragranceEngine;
}

export default function FragranceSimulator({ fragranceEngine }: FragranceSimulatorProps) {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<EnhancedBlendingResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = async () => {
    if (!input.trim()) return;
    
    setIsLoading(true);
    try {
      const searchResult = fragranceEngine.analyzeFragranceRequestEnhanced(input);
      setResult(searchResult);
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const exampleQueries = [
    '清新的森林氣味',
    '甜美花香',
    '温暖舒緩的香氣',
    '提神醒腦的味道',
    '浪漫的晚上香氣'
  ];

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.7) return 'text-green-600';
    if (confidence >= 0.4) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getConfidenceLabel = (confidence: number) => {
    if (confidence >= 0.7) return '高度匹配';
    if (confidence >= 0.4) return '中等匹配';
    return '低度匹配';
  };

  return (
    <div className="bg-gradient-to-br from-green-50 to-amber-50 rounded-2xl p-8 shadow-lg">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Sparkles className="text-green-600" size={32} />
          <h2 className="text-3xl font-bold text-gray-800">香氣模擬器</h2>
        </div>
        <p className="text-gray-600 text-lg">
          輸入您理想中的香氣描述，我們為您智能推薦適合的精油
        </p>
      </div>

      <div className="max-w-2xl mx-auto mb-8">
        {/* 使用說明 */}
        <div className="mb-3 text-center">
          <p className="text-sm text-gray-600 bg-blue-50 px-4 py-2 rounded-lg border border-blue-200 inline-block flex items-center justify-center gap-1">
            📝 輸入您的香氣描述後，請點擊 <span className="text-green-600 font-semibold">綠色放大鏡圖標</span> <Search className="inline-block text-green-600" size={16} /> 開始模擬
          </p>
        </div>
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="例如：清新的森林氣味、甜美花香、温暖舒緩..."
            className="w-full px-6 py-4 pr-14 text-lg rounded-xl border-2 border-green-200 focus:border-green-400 focus:outline-none focus:ring-2 focus:ring-green-200 transition-all duration-200"
          />
          <button
            onClick={handleSearch}
            disabled={isLoading || !input.trim()}
            className="absolute right-2 top-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white p-2 rounded-lg transition-colors duration-200"
          >
            <Search size={20} />
          </button>
        </div>
        
        <div className="mt-4">
          <p className="text-sm text-gray-500 mb-2">热門搜尋：</p>
          <div className="flex flex-wrap gap-2">
            {exampleQueries.map((query, index) => (
              <button
                key={index}
                onClick={() => setInput(query)}
                className="bg-white hover:bg-green-50 text-gray-700 px-3 py-1 rounded-lg text-sm border border-gray-200 hover:border-green-300 transition-all duration-200"
              >
                {query}
              </button>
            ))}
          </div>
        </div>
      </div>

      {isLoading && (
        <div className="text-center py-8">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          <p className="text-gray-600 mt-2">正在分析您的香氣需求...</p>
        </div>
      )}

      {result && !isLoading && (
        <div className="space-y-6">
          {/* 單方推薦 */}
          {result.singleRecommendation && (
            <div className="bg-white rounded-xl p-6 shadow-md border-l-4 border-green-500">
              <div className="flex items-center gap-3 mb-4">
                <Star className="text-green-600" size={24} />
                <h3 className="text-xl font-bold text-gray-800">單方精油推薦</h3>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  result.singleRecommendation.confidence >= 0.7 ? 'bg-green-100 text-green-700' :
                  result.singleRecommendation.confidence >= 0.4 ? 'bg-yellow-100 text-yellow-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {getConfidenceLabel(result.singleRecommendation.confidence)}
                </span>
              </div>
              
              <p className="text-gray-700 mb-4 text-lg">{result.singleRecommendation.reason}</p>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <OilCard 
                    oil={result.singleRecommendation.oil} 
                    fragranceEngine={fragranceEngine}
                  />
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-800 mb-3">精油特性</h4>
                  <p className="text-sm text-gray-700 leading-relaxed mb-3">
                    {result.singleRecommendation.characteristics.description}
                  </p>
                  <div>
                    <h5 className="font-medium text-gray-800 mb-2">適合應用：</h5>
                    <div className="flex flex-wrap gap-2">
                      {result.singleRecommendation.characteristics.applications.map((app, index) => (
                        <span key={index} className="bg-white text-gray-600 px-2 py-1 rounded-md text-xs border">
                          {app}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 複方推薦 */}
          {result.blendRecommendation && (
            <div className="bg-white rounded-xl p-6 shadow-md border-l-4 border-amber-500">
              <div className="flex items-center gap-3 mb-4">
                <Lightbulb className="text-amber-600" size={24} />
                <h3 className="text-xl font-bold text-gray-800">
                  {result.singleRecommendation ? '補充複方推薦' : '複方精油推薦'}
                </h3>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  result.blendRecommendation.confidence >= 0.7 ? 'bg-green-100 text-green-700' :
                  result.blendRecommendation.confidence >= 0.4 ? 'bg-yellow-100 text-yellow-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {getConfidenceLabel(result.blendRecommendation.confidence)}
                </span>
              </div>
              
              <p className="text-gray-700 mb-6 text-lg">{result.blendRecommendation.reason}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {result.blendRecommendation.oils.map((oil) => (
                  <OilCard key={oil.id} oil={oil} fragranceEngine={fragranceEngine} />
                ))}
              </div>

              {/* 調配教學 */}
              <div className="mt-6">
                <BlendingGuide 
                  recipe={fragranceEngine.generateBlendingRecipe(result.blendRecommendation.oils)}
                  fragranceEngine={fragranceEngine}
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}