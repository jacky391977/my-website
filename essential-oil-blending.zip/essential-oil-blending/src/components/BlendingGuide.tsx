import { useState } from 'react';
import { BlendingRecipe } from '../types/EssentialOil';
import { ChevronDown, ChevronUp, Beaker, Clock, Lightbulb } from 'lucide-react';
import OilCard from './OilCard';
import { FragranceEngine } from '../services/FragranceEngine';

interface BlendingGuideProps {
  recipe: BlendingRecipe;
  fragranceEngine: FragranceEngine;
}

export default function BlendingGuide({ recipe, fragranceEngine }: BlendingGuideProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl p-6 shadow-md border border-amber-200">
      <div className="text-center mb-4">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Beaker className="text-amber-600" size={24} />
          <h3 className="text-xl font-bold text-gray-800">建議調配教學</h3>
        </div>
        <button
          className="bg-amber-500 hover:bg-amber-600 text-white px-6 py-3 rounded-lg font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-200 flex items-center gap-2 mx-auto"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <span>
            {isExpanded ? '收合' : '展開'}詳細步驟
          </span>
          {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </button>
      </div>

      {isExpanded && (
        <div className="mt-6 space-y-6 animate-slide-up">
          {/* 基本信息 */}
          <div className="bg-white rounded-lg p-4 border border-amber-100">
            <h4 className="font-semibold text-gray-800 mb-3">配方基本信息</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">基底油：</span>
                <span className="font-medium">{recipe.baseOil}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">總容量：</span>
                <span className="font-medium">{recipe.totalVolume}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">精油總滴數：</span>
                <span className="font-medium">
                  {recipe.ingredients.reduce((sum, ing) => sum + ing.drops, 0)} 滴
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">稀釋比例：</span>
                <span className="font-medium">1:20 (5%)</span>
              </div>
            </div>
          </div>

          {/* 精油成分 */}
          <div className="bg-white rounded-lg p-4 border border-amber-100">
            <h4 className="font-semibold text-gray-800 mb-3">精油成分與用量</h4>
            <div className="space-y-3">
              {recipe.ingredients
                .sort((a, b) => a.order - b.order)
                .map((ingredient, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <span className="bg-amber-100 text-amber-700 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold">
                      {ingredient.order}
                    </span>
                    <div>
                      <p className="font-medium text-gray-800">{ingredient.oil.chinese_name}</p>
                      <p className="text-sm text-gray-500">{ingredient.oil.name}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-amber-600">{ingredient.drops} 滴</p>
                    <p className="text-xs text-gray-500">{ingredient.percentage}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 調配步驟 */}
          <div className="bg-white rounded-lg p-4 border border-amber-100">
            <div className="flex items-center gap-2 mb-3">
              <Clock className="text-amber-600" size={20} />
              <h4 className="font-semibold text-gray-800">調配步驟</h4>
            </div>
            <div className="space-y-3">
              {recipe.steps.map((step, index) => (
                <div key={index} className="flex gap-3">
                  <span className="bg-amber-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                    {index + 1}
                  </span>
                  <p className="text-gray-700 leading-relaxed">{step}</p>
                </div>
              ))}
            </div>
          </div>

          {/* 專業提醒 */}
          <div className="bg-white rounded-lg p-4 border border-amber-100">
            <div className="flex items-center gap-2 mb-3">
              <Lightbulb className="text-amber-600" size={20} />
              <h4 className="font-semibold text-gray-800">專業提醒</h4>
            </div>
            <div className="space-y-2">
              {recipe.tips.map((tip, index) => (
                <div key={index} className="flex gap-2">
                  <span className="text-amber-500 mt-1">•</span>
                  <p className="text-sm text-gray-600 leading-relaxed">{tip}</p>
                </div>
              ))}
            </div>
          </div>

          {/* 推薦精油卡片 */}
          <div className="bg-white rounded-lg p-4 border border-amber-100">
            <h4 className="font-semibold text-gray-800 mb-3">所需精油</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {recipe.ingredients.map((ingredient, index) => (
                <OilCard 
                  key={index} 
                  oil={ingredient.oil} 
                  fragranceEngine={fragranceEngine}
                  showBuyButton={true}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}