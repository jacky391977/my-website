import { EssentialOil } from '../types/EssentialOil';
import { ExternalLink, ShoppingCart } from 'lucide-react';
import { FragranceEngine } from '../services/FragranceEngine';

interface OilCardProps {
  oil: EssentialOil;
  showBuyButton?: boolean;
  fragranceEngine?: FragranceEngine;
}

export default function OilCard({ oil, showBuyButton = true, fragranceEngine }: OilCardProps) {
  const handleBuyClick = () => {
    const purchaseUrl = fragranceEngine 
      ? fragranceEngine.getPurchaseLink(oil.name)
      : 'https://www.stardi.com.tw/collections/single-essential-oil';
    window.open(purchaseUrl, '_blank');
  };

  const getNoteColor = (note: string) => {
    switch (note) {
      case 'top': return 'bg-green-100 text-green-700';
      case 'middle': return 'bg-amber-100 text-amber-700';
      case 'base': return 'bg-rose-100 text-rose-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getNoteLabel = (note: string) => {
    switch (note) {
      case 'top': return '前調';
      case 'middle': return '中調';
      case 'base': return '後調';
      default: return note;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all duration-300 hover:border-green-200">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-800 mb-1">
            {oil.chinese_name}
          </h3>
          <p className="text-sm text-gray-500 mb-2">{oil.name}</p>
          <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getNoteColor(oil.notes)}`}>
            {getNoteLabel(oil.notes)}
          </span>
        </div>
        {showBuyButton && (
          <button
            onClick={handleBuyClick}
            className="bg-green-600 hover:bg-green-700 text-white p-2 rounded-lg transition-colors duration-200 flex items-center gap-1"
            title="前往購買"
          >
            <ShoppingCart size={16} />
          </button>
        )}
      </div>
      
      <div className="mb-4">
        <p className="text-gray-700 font-medium mb-2">{oil.scent_profile}</p>
        <div className="flex flex-wrap gap-1">
          {oil.properties.map((property, index) => (
            <span
              key={index}
              className="bg-gray-50 text-gray-600 px-2 py-1 rounded-md text-xs"
            >
              {property}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}