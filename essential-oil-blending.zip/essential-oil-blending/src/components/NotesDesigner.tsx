import { useState } from 'react';
import { FragranceEngine } from '../services/FragranceEngine';
import { FragranceProfile, BlendAnalysis } from '../types/EssentialOil';
import { Layers, ChevronRight, Clock } from 'lucide-react';
import OilCard from './OilCard';
import BlendingGuide from './BlendingGuide';

interface NotesDesignerProps {
  fragranceEngine: FragranceEngine;
}

export default function NotesDesigner({ fragranceEngine }: NotesDesignerProps) {
  const [profile, setProfile] = useState<FragranceProfile>({
    top: '',
    middle: '',
    base: ''
  });
  const [analysis, setAnalysis] = useState<BlendAnalysis | null>(null);

  const handleInputChange = (noteType: keyof FragranceProfile, value: string) => {
    setProfile(prev => ({ ...prev, [noteType]: value }));
  };

  const handleAnalyze = () => {
    if (!profile.top && !profile.middle && !profile.base) return;
    
    const result = fragranceEngine.analyzeBlendProfile(profile);
    setAnalysis(result);
  };

  const noteExamples = {
    top: ['清新', '柑橘', '草本', '薬草', '提神'],
    middle: ['花香', '辦子', '温暖', '平衡', '美容'],
    base: ['木質', '樹脂', '沈穩', '温暖', '神聖']
  };

  const noteInfo = {
    top: { label: '前調', color: 'border-green-300 bg-green-50', desc: '初聞香氣，持續10-15分鐘' },
    middle: { label: '中調', color: 'border-amber-300 bg-amber-50', desc: '主體香氣，持續2-4小時' },
    base: { label: '後調', color: 'border-rose-300 bg-rose-50', desc: '基底香氣，持續6-8小時' }
  };

  return (
    <div className="bg-gradient-to-br from-amber-50 to-rose-50 rounded-2xl p-8 shadow-lg">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Layers className="text-amber-600" size={32} />
          <h2 className="text-3xl font-bold text-gray-800">前中後調設計</h2>
        </div>
        <p className="text-gray-600 text-lg">
          設計您的專屬香調組合，創造層次豐富的香氣體驗
        </p>
      </div>

      <div className="max-w-4xl mx-auto mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {(Object.keys(noteInfo) as Array<keyof typeof noteInfo>).map((noteType) => {
            const info = noteInfo[noteType];
            return (
              <div key={noteType} className={`rounded-xl border-2 ${info.color} p-6`}>
                <div className="flex items-center gap-2 mb-3">
                  <Clock size={20} className="text-gray-600" />
                  <h3 className="text-lg font-semibold text-gray-800">{info.label}</h3>
                </div>
                <p className="text-sm text-gray-600 mb-4">{info.desc}</p>
                
                <textarea
                  value={profile[noteType] || ''}
                  onChange={(e) => handleInputChange(noteType, e.target.value)}
                  placeholder={`描述您理想的${info.label}香氣...`}
                  className="w-full p-3 border border-gray-200 rounded-lg focus:border-gray-400 focus:outline-none resize-none h-20"
                />
                
                <div className="mt-3">
                  <p className="text-xs text-gray-500 mb-2">常用描述：</p>
                  <div className="flex flex-wrap gap-1">
                    {noteExamples[noteType].map((example, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          const current = profile[noteType] || '';
                          const newValue = current ? `${current}、${example}` : example;
                          handleInputChange(noteType, newValue);
                        }}
                        className="bg-white hover:bg-gray-50 text-gray-700 px-2 py-1 rounded text-xs border border-gray-200 hover:border-gray-300 transition-all duration-200"
                      >
                        {example}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center">
          <button
            onClick={handleAnalyze}
            disabled={!profile.top && !profile.middle && !profile.base}
            className="bg-amber-600 hover:bg-amber-700 disabled:bg-gray-400 text-white px-8 py-3 rounded-xl font-semibold text-lg transition-colors duration-200 flex items-center gap-2 mx-auto"
          >
            分析香調組合
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      {analysis && (
        <div className="bg-white rounded-xl p-6 shadow-md">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">香調分析結果</h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-3">香氣演變</h4>
              <p className="text-gray-700 leading-relaxed">{analysis.evolution}</p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-3">應用場合</h4>
              <div className="space-y-3">
                {analysis.applications.map((app, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <span className="text-2xl">{app.icon}</span>
                    <div>
                      <p className="font-medium text-gray-800">{app.occasion}</p>
                      <p className="text-sm text-gray-600">{app.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {analysis.recommendedOils.length > 0 && (
            <div>
              <h4 className="text-lg font-semibold text-gray-800 mb-4">推薦精油</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {analysis.recommendedOils.map((oil) => (
                  <OilCard key={oil.id} oil={oil} fragranceEngine={fragranceEngine} />
                ))}
              </div>

              {/* 調配教學 */}
              <div className="mt-6">
                <BlendingGuide 
                  recipe={fragranceEngine.generateBlendingRecipe(analysis.recommendedOils)}
                  fragranceEngine={fragranceEngine}
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}